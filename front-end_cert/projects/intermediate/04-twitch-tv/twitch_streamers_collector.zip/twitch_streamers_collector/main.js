$(document).ready(function(){
  var users = ["ESL_SC2", "OgamingSC2", "cretetion", "freecodecamp",
    "storbeck", "habathcx", "RobotCaleb", "noobs2ninjas"];
  var url = "https://wind-bow.hyperdev.space/twitch-api/";

  var type = ['channels', 'users', 'streams'];
  cb = '?callback=?';

  var data = {};

  var counter = 0;
  users.forEach(function(u){
    data[u] = {};
    type.forEach(function(t){
      $.getJSON(url+t+'/'+u+cb,function(res){
        data[u][t] = res;
        counter++;
        if(counter == 3*users.length) {
          console.log(data);
          $('body').text(JSON.stringify(data));
        }
      })
    })
  });

})
