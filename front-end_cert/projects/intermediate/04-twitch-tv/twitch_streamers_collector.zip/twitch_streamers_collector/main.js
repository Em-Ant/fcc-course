$(document).ready(function(){

  var url = "https://wind-bow.hyperdev.space/twitch-api/";

  var users = ["ESL_SC2", "OgamingSC2", "cretetion", "freecodecamp",
    "storbeck", "habathcx", "RobotCaleb", "noobs2ninjas"];

  var types = ['channels', 'users', 'streams'];
  cb = '?callback=?';

  var data = {};

  var counter = 0;
  users.forEach(function(u){
    data[u] = {};
    types.forEach(function(t){
      $.getJSON(url+t+'/'+u+cb,function(res){
        data[u][t] = res;
        counter++;
        console.log(counter);
        if(counter == types.length*users.length) {
          $('body').text(JSON.stringify(data));
        }
      })
    })
  });
})
